﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymMy
{
    using static GlobalVariable;
    public partial class AdminRedeem : Form
    {
        public AdminRedeem()
        {
            InitializeComponent();
            LoadDataRedeem();
        }

        public void LoadDataRedeem()
        {
            try
            {
                connection.Open();
                sqlQuery = "SELECT users.nama, status FROM user_redeem JOIN users ON users.user_id = user_redeem.user_point_id where status = 0";
                command = new SqlCommand(sqlQuery, connection.Connection);
                command.ExecuteNonQuery();
                adapter = new SqlDataAdapter(command);

                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvRedeem.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Tidak ada data request saat ini {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.Close();
            }
        }
        private void buttonBack_Click(object sender, EventArgs e)
        {
            admin.Show();
            this.Hide();
        }

        private void UpdateStatusInDatabase()
        {
            try
            {
                connection.Open();
            SqlCommand updateCommand = new SqlCommand("UPDATE user_redeem SET status = 1", connection.Connection);
            updateCommand.ExecuteNonQuery();
            }
            catch(Exception ex)
            {
                MessageBox.Show("Gagal Mengupdate data", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.Close();
            }
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            try
            {
            UpdateStatusInDatabase();
            }
            catch
            {
                MessageBox.Show("Berhasil menerima request data redeem");
            }
        }
    }
}
