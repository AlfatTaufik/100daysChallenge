﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data.SqlTypes;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GymMy
{
    internal class GlobalVariable
    {
        public static DatabaseConnection connection = new DatabaseConnection();
        public static string sqlQuery;
        public static SqlCommand command;
        public static SqlDataReader dataReader;
        public static SqlDataAdapter adapter;

        public static FormLogin login;
        public static AdminRedeem redeemAdmin;
        public static AdminMember memberAdmin;

        public static CustomerForm customer;
        public static AdminForm admin;
        public static CheckInHistory checkin;
    }
}
