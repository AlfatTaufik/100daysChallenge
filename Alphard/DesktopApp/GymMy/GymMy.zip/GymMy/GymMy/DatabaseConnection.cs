﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Threading.Tasks;

namespace GymMy
{
    internal class DatabaseConnection
    {
        public SqlConnection Connection = new SqlConnection(Properties.Settings.Default.connection);

        public void Open()
        {
            if(Connection.State == ConnectionState.Closed)
            {
                Connection.Open();
            }
            else
            {
                Connection.Close();
                Connection.Open();
            }
        }
        public void Close()
        {
            Connection.Close();
        }
    }
}
