﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymMy
{
    using static GlobalVariable;
    internal static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            login = new FormLogin();
            admin = new AdminForm();
            redeemAdmin = new AdminRedeem();
            memberAdmin = new AdminMember();
            //customer = new CustomerForm();
            //checkin = new CheckInHistory();
            Application.Run(login);
        }
    }
}
