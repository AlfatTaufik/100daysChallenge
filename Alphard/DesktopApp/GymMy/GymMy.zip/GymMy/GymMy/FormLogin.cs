﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GymMy
{
    using static GlobalVariable;
    public partial class FormLogin : Form
    {
        public FormLogin()
        {
            InitializeComponent();
        }

        private void checkBoxShowPass_CheckedChanged(object sender, EventArgs e)
        {
            fieldPassword.PasswordChar = checkBoxShowPass.Checked ? '\0' : '*';
        }

        private bool isInputValid()
        {
            if (string.IsNullOrWhiteSpace(fieldUsername.Text) && string.IsNullOrWhiteSpace(fieldPassword.Text))
            {
                MessageBox.Show("Field Username dan password tidak boleh kosong", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else if (string.IsNullOrWhiteSpace(fieldUsername.Text))
            {
                MessageBox.Show("Field Username tidak boleh kosong", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            else if (string.IsNullOrWhiteSpace(fieldPassword.Text))
            {
                MessageBox.Show("Field Password tidak boleh kosong", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
            return true;
        }

        private void buttonLogin_Click(object sender, EventArgs e)
        {
            if (isInputValid())
            {
                try
                {
                    connection.Open();
                    sqlQuery = "SELECT * FROM users WHERE nama = @username AND password = @password AND deleted_at IS NULL";
                    command = new SqlCommand(sqlQuery, connection.Connection);
                    command.Parameters.AddWithValue("@username", fieldUsername.Text);
                    command.Parameters.AddWithValue("@password", fieldPassword.Text);
                    dataReader = command.ExecuteReader();

                    if (dataReader.Read())
                    {
                        if (dataReader["role"].ToString() == "admin")
                        {
                            admin.Show();
                            this.Hide();
                        }
                        else
                        {
                            int userId = Convert.ToInt32(dataReader["user_id"]);
                            customer = new CustomerForm(userId);
                            customer.Show();
                            this.Hide();
                        }
                        MessageBox.Show($"Login Berhasil halo {fieldUsername.Text}", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show($"Gagal Login Username atau Password Salah", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Gagal Login Username atau Password Salah: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                finally
                {
                    connection.Close();
                }
            }
        }

    }
}
