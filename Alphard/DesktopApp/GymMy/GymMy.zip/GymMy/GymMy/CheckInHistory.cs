﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymMy
{
    using static GlobalVariable;
    public partial class CheckInHistory : Form
    {
        private int id;
        public CheckInHistory(int id)
        {
            this.id = id;
            InitializeComponent();
            LoadDateData(id);
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            customer.Show();
            this.Hide();
        }

        public void LoadDateData(int userId)
        {
            this.id = userId;
            try
            {
                connection.Open();
                sqlQuery = "SELECT check_in as Date FROM user_checkin WHERE user_id = @id";
                command = new SqlCommand(sqlQuery, connection.Connection);
                command.Parameters.AddWithValue("@id", id);
                adapter = new SqlDataAdapter(command);

                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvHistory.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.Close();
            }
        }

        protected override void OnShown(EventArgs e)
        {
            //LoadDateData(id);
        }
    }
}
