﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymMy
{
    using static GlobalVariable;
    public partial class AdminMember : Form
    {
        public AdminMember()
        {
            InitializeComponent();
            LoadDataMember();
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            admin.Show();
            this.Hide();
        }

        public void LoadDataMember()
        { 
            try
            {
                connection.Open();
                sqlQuery = "SELECT nama, email, is_member as Accept FROM users where is_member = 0";
                command = new SqlCommand(sqlQuery, connection.Connection);
                command.ExecuteNonQuery();
                adapter = new SqlDataAdapter(command);

                DataTable dt = new DataTable();
                adapter.Fill(dt);
                dgvMember.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Tidak ada data request saat ini", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.Close();
            }
        }

        private void UpdateStatusInDatabase()
        {
            try
            {
                connection.Open();
                SqlCommand updateCommand = new SqlCommand("UPDATE users SET is_member = 1", connection.Connection);
                updateCommand.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gagal Mengupdate data", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.Close();
            }
        }

        private void buttonUpdate_Click(object sender, EventArgs e)
        {
            try
            {
                UpdateStatusInDatabase();
            }
            catch
            {
                MessageBox.Show("Berhasil menerima request data redeem");
            }
        }
    }
}
