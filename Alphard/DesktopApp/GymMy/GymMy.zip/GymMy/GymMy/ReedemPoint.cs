﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymMy
{
    using static GlobalVariable;
    public partial class ReedemPoint : Form
    {
        private int id;
        public ReedemPoint(int id)
        {
            InitializeComponent();
            this.id = id;
            CalculateTotalPoints(id);
        }

        private void CalculateTotalPoints(int id)
        {
            int totalPoint = 0;
            try
            {
                connection.Open();
                sqlQuery = "Select point from user_checkin where user_id = @id";
                command = new SqlCommand(sqlQuery, connection.Connection);
                command.Parameters.AddWithValue("@id", id);
                dataReader = command.ExecuteReader();

                while (dataReader.Read())
                {
                    int point;
                    if(int.TryParse(dataReader["point"].ToString(), out point))
                    {
                        totalPoint += point;
                    }
                    
                    fieldPointNow.Text = totalPoint.ToString();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("Kamu belum pernah checkin", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.Close();
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int pointNow = int.Parse(fieldPointNow.Text);
            int pointEx = int.Parse(fieldExchange.Text);
            if(pointEx > pointNow)
            {
                MessageBox.Show("Pointmu kurang");
            }

            int remain = pointNow - pointEx;
            fieldPoinLater.Text = remain.ToString();
        }

        private void buttonRedeem_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();
                sqlQuery = "Insert into user_redeem(user_point_id, redeem_point, status, created_at) values(@id, @point, 0, GETDATE())";
                command = new SqlCommand(sqlQuery, connection.Connection);
                command.Parameters.AddWithValue("@id", id);
                command.Parameters.AddWithValue("@point", fieldExchange.Text);

                MessageBox.Show("Data Berhasil dimasukan", "Berhasil", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Gagal memasukan redeem", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.Close();
            }
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            customer.Show();
            this.Hide();
        }
    }
}
