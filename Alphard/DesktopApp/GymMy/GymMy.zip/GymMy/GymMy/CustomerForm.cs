﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GymMy
{
    using static GlobalVariable;
    public partial class CustomerForm : Form
    {
        private int userid;
        private bool hasCheckedinToday = false;
        public CustomerForm(int id)
        {
            InitializeComponent();
            this.userid = id;
            isUserCheckIn();
        }

        private void isUserCheckIn()
        {
            try
            {
                connection.Open();
                sqlQuery = "Select TOP 1 user_id from user_checkin where user_id = @userId AND Convert(DATE, check_in) = Convert(DATE, GETDATE())";
                command = new SqlCommand(sqlQuery, connection.Connection);
                command.Parameters.AddWithValue("@userId", userid);

                object result = command.ExecuteScalar();
                hasCheckedinToday = (result != null && result != DBNull.Value);
            }
            finally
            {
                connection.Close();
            }
        }


        private void button1_Click(object sender, EventArgs e)
        {

            try
            {
                connection.Open();

                if (!hasCheckedinToday)
                {
                    sqlQuery = "INSERT INTO user_checkin(user_id, check_in, point) VALUES(@userId, GETDATE(), 5)";
                    command = new SqlCommand(sqlQuery, connection.Connection);
                    command.Parameters.AddWithValue("@userId", userid);
                    command.ExecuteNonQuery();

                    hasCheckedinToday = true;
                    button1.Enabled = false;
                    MessageBox.Show("Input checkin berhasil, silakan lihat history Anda");
                }
                else
                {
                    MessageBox.Show("Kamu sudah checkin hari ini", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show($"Kamu sudah checkin hari ini{ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            finally
            {
                connection.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            CheckInHistory history = new CheckInHistory(userid);
            history.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ReedemPoint reedem = new ReedemPoint(userid);
            reedem.Show();
            this.Hide();
        }

        private void buttonLogOut_Click(object sender, EventArgs e)
        {
            login = new FormLogin();
            login.Show();
            this.Hide();
        }
    }
}
